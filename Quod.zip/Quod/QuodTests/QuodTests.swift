//
//  QuodTests.swift
//  QuodTests
//
//  Created by Mariana Federico on 02/12/24.
//

import Testing
@testable import Quod

struct QuodTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
