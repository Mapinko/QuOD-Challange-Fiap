//
//  QuodApp.swift
//  Quod
//
//  Created by Mariana Federico on 02/12/24.
//

import SwiftUI

@main
struct QuodApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
